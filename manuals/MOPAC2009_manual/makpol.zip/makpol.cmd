echo off
REM
REM  Run Program MAKPOL
REM
if x%1 == x goto description
if NOT EXIST make_%1.dat goto missing
s:\utility\makpol-F90 make_%1
DEL *temp_makpol
vi %1.dat
goto finish
:description

ECHO :                        Program MAKPOL
ECHO :  	
ECHO :  MAKPOL constructs a MOPAC data set for a polymer, layer system, or solid.
ECHO :  It uses a MOPAC-type data set that contains information about the size of
ECHO :  the cluster to be built.  For a description of MAKPOL, see:
ECHO :
ECHO : http://www.OpenMOPAC.net/Manual/makpol.html
ECHO :  
ECHO :  Keywords specific to MAKPOL are:
ECHO :  
ECHO :  MERS=(n,m,l): number of unit cells in each direction, can be fractional, e.g. 1.5.
ECHO :                If fractional, then the associated Tv must be a multiple
ECHO :                of the primitive Tv.
ECHO :  BCC         : All odd unit cells (cells with indices i+j+k odd) omitted.
ECHO :  
ECHO :  More than a unit cell can be supplied.  The extra atoms will be automatically deleted.
ECHO :  The translation vectors can be anywhere in the data set.
ECHO :  If the unit cell contains discrete molecules, they will be preserved intact in the
ECHO :  resulting MOPAC data set.
ECHO :  
ECHO :  If SYMMETRY is present, it'll be used, and also used in constructing the data set.
ECHO :  
ECHO :  As an example, the following illustrates a simple MAKPOL data set.
ECHO :  
ECHO :       MERS=(2,2,1) 
ECHO : Aspartic acid
ECHO : 
ECHO :   C    0.000  1   0.000  1   0.000  1  
ECHO :   H    0.475  1   0.442  1   0.798  1  
ECHO :   H   -0.195  1   0.547  1  -1.882  1  
ECHO :   H    1.040  1   1.273  1  -1.360  1  
ECHO :   N    0.023  1   0.966  1  -1.140  1  
ECHO :   C    0.653  1  -1.316  1  -0.384  1  
ECHO :   H    3.838  1  -0.542  1  -0.190  1  
ECHO :   H    0.526  1  -1.869  1   0.418  1  
ECHO :   O    2.848  1  -0.600  1   0.121  1  
ECHO :   C    2.116  1  -1.226  1  -0.759  1  
ECHO :   H    0.242  1  -1.750  1  -1.061  1  
ECHO :   O    2.551  1  -1.737  1  -1.757  1  
ECHO :   C   -1.463  1  -0.291  1   0.392  1  
ECHO :   O   -2.289  1  -0.372  1  -0.546  1  
ECHO :   O   -1.701  1  -0.470  1   1.598  1  
ECHO :   H   -0.585  1   1.706  1  -0.818  1  
ECHO :   C   -1.876  1   3.200  1   0.990  1  
ECHO :   C   -3.340  1   3.491  1   1.382  1  
ECHO :   C   -3.993  1   2.175  1   1.766  1  
ECHO :   C   -5.455  1   2.265  1   2.142  1  
ECHO :   H   -7.178  1   2.949  1   1.573  1  
ECHO :   H   -3.865  1   1.622  1   0.965  1  
ECHO :   H   -3.581  1   1.741  1   2.444  1  
ECHO :   H   -3.145  1   4.038  1   3.265  1  
ECHO :   H   -2.754  1   5.197  1   2.201  1  
ECHO :   H   -4.379  1   4.764  1   2.743  1  
ECHO :   H   -3.815  1   3.933  1   0.585  1  
ECHO :   N   -3.363  1   4.457  1   2.523  1  
ECHO :   O   -1.050  1   3.119  1   1.928  1  
ECHO :   O   -1.639  1   3.021  1  -0.216  1  
ECHO :   O   -5.890  1   1.754  1   3.139  1  
ECHO :   O   -6.188  1   2.891  1   1.261  1  
ECHO :  Tv   -0.879  1   0.000  1   5.066  1  
ECHO :  Tv    0.000  1   6.982  1   0.000  1  
ECHO :  Tv    7.617  1   0.000  1   0.000  1  
ECHO :  

ECHO :   
goto finish
:missing
Echo File "make_%1.dat" is missing
:finish
